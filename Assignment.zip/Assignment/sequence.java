/*  que 1: find sequence of char in sentence using default method.  */

interface SeqInterface
{
	default void show()
	{
	String s = "Default sentence is Here";
	System.out.println("\n Default Method is Executed Here!!!! ");
	}
}
class sequence implements SeqInterface
{
 public void show()
 {
	 SeqInterface.super.show();
 }
 public static void main(String[] args)
 {
	 sequence s = new sequence();
	 s.show();
 }
}
