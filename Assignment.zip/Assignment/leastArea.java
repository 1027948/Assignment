import java.util.Scanner;

public class leastArea
{
    public static void main(String args[]) 
    {
        final int SIZE = 10;
        Scanner in = new Scanner(System.in);
        String cities[] = new String[SIZE];
        String stdCodes[] = new String[SIZE];
        System.out.println("Enter " + SIZE +  " cities and their least area codes:");
        
        for (int i = 0;  i < SIZE; i++) 
        {
            System.out.print("Enter City Name: ");
            cities[i] = in.nextLine();
            System.out.print("Enter least Area code: ");
            stdCodes[i] = in.nextLine();
        }
        System.out.print("******************************");
        System.out.print("Enter name of city to search: ");
        String city = in.nextLine();
        
        int idx;
        for (idx = 0;  idx < SIZE; idx++) 
        {
            if (city.compareToIgnoreCase(cities[idx]) == 0)
             {
                break;
            }
        }
        
        if (idx < SIZE) {
            System.out.println("Search Successful");
            System.out.println("City: " + cities[idx]);
            System.out.println("least area Code: " + stdCodes[idx]);
        }
        else {
            System.out.println("Search Unsuccessful");
        }
    }
}