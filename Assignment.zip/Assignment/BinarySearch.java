import javax.lang.model.element.Element;

public class BinarySearch
{
    public static void binarySearch(int arr[],int first,int last,int key) 
    {
     int mid =(first+last)/2;
       if(arr[mid]<key)
       {
         first=mid+1;
       }   
       else if (arr [mid]==key)
       {
        System.out.println("Element is found at index:"+mid);
        break;
       }else{
         last=mid-1;
       }
     mid=(first+last)/2;
    }
     if(first > last)
     {
         System.out.println("Element is not found!!!!!!");
     }
}
    public static void main(String args[])
    {
        int arr[] ={10,20,30,40,50};
        int key=30;
        int last =arr.length-1;
        D lambda=() ->
        binarySearch(arr,0,last,key);
        System.out.println();
        lambda.Binary();
    }
}
/*import java.util.ArrayList;
import java.util.Collections;
interface Binary
{
    void BSearch();
}

public class BinarySearch 
{
public static void main(String[] args)  
   {
           Binary b =()->
           {
            int arr[]= {12,14,15,13,17,18,19};
            ArrayList<Integer> ele = new  ArrayList <Integer>();
            for(int i=0;i<arr.length;i++)
            {
             ele.add(arr[i]);
            }
            int search = Collections.binarySearch(ele,17);
            System.out.println("Element is at Index :: "+search);
            };
    b.BSearch();
    }
}
*/
