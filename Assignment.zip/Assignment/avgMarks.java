/* que 1- average marks.*/
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
class Student
{
    int studId;
    String studName;
    int studMarks;
    public Student (int studId, String studName, int studMarks)
    {   this.studId=studId;
        this.studName=studName;
        this.studMarks=studMarks;
    }
}
public class avgMarks
{ public static void main(String args[]) {
      List<Student> list= new ArrayList<Student>();
      list.add(new Student(101,"isha Deshmukh",76));  
      list.add(new Student(102,"pallavi patil",68));
      list.add(new Student(103,"pratiksha Nimbalkar",75));
      list.add(new Student(104,"poonam Deshpande",79));
      list.add(new Student(105,"pranoti Shinde",69));
      System.out.println("Student Average Marks:: ");
      /* optimal double : is a value based class. use of identity sensitive operations (including refrence eqality(==)
      instances of OptimalDouble may have Unpredictable results and  should be avoided.) */
      OptionalDouble StudAvgMarks = list.stream().mapToInt(sv->sv.studMarks).average();
      System.out.println(StudAvgMarks);
     }
}