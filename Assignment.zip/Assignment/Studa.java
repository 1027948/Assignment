
import java.sql.Array;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Studa
{
    List<String> names = Array.ArrayList("anuradha","Isha","Aarohi","Ambrapali","ashu","amey");
    Stream<String> s= names.stream().filter(name -> name.startsWith("A"));
    Stream<String> s= names.stream().filter(name -> name.startsWith("a"));
    System.out.println(s.collect(Collectors.toList()));
}

/*
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class Studa
{
     public static void main(String[] args) 
     {
        ArrayList<String> name = new ArrayList<>();
        name.add("Ishu");
        name.add("anuradha");
        name.add("monali");
        name.add("Ambrapali");
        name.add("ashutosh");
        name.add("Jayshri");
        name.add("anand");
        name.add("Arohi");

        //ArrayList<String> R = name.stream().filter(x -> x.toUpperCase().charAt(0)=='A').collect(Collectors.toList());
        //System.out.println("The String Start with A" +R);
        
        
        ArrayList<String> R = name.stream().filter(x->x.startsWith("A") || x.startsWith("a")).collect(Collectors.toList());
        System.out.println("The String Start with A" +R);
        
    }
}
*/


/*System.out.println("\nStarting with Small laters 'a' ::");
        List<String> list = name.stream().filter(x -> x.startsWith("a")).collect(Collectors.toList());
        System.out.println(list);
        System.out.println("\nStarting with Capital laters 'A' ::");
        List<String> list2 = name.stream().filter(x -> x.startsWith("A")).collect(Collectors.toList());
        System.out.println(list2);
        */