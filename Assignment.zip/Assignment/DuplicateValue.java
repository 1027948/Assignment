/* que 4:  find the duplicate value count of number a given no. */
public class DuplicateValue
{
	public static void main(String s[])
	{
		int co=0,Num=17;
		int arr[]= {13,24,17,16,17,18,17,12,17};
		for(int i=0;i< arr.length;i++)
		{
			if(arr[i]==Num)
			{
              co++;
			}
		}
		System.out.println("\nAll Duplicate Numbers is present in output screen : "+(co-1));
	}
}



/*
interface I3
{
default void display()

{
	int i,j;
	int a[]={10,20,30,40,40};
	for(i=0; i<a.length; i++)
	{
      for(j=i+1; j<a.length; j++)
	  {
		  if(a[i]==a[j])
		  {
			  System.out.println("Duplicate Number is: "+a[i]);
		  }
		  else{
			  System.out.println("Duplicate Number is Not found!!!!");
		  }
	  }
	}
}
}
*/



/* que 4:  find the duplicate value count of number a given no. */
/*
import java.util.*;

class Duplicate
{	
    static HashMap<Integer, Integer> findRepeating(int []arr, int size)
	{
	/* Hash map to store the frequency of number.*/
	//HashMap<Integer,Integer> freq = new HashMap<Integer,Integer>();

	/* Loop to store the frequency of number of array.*/
	/*for(int i = 0; i < size; i++)
	{
		if(freq.containsKey(arr[i]))
		{
			freq.put(arr[i], freq.get(arr[i]) + 1);
		}
		else
		{
			freq.put(arr[i], 1);
		}
	}
	return freq;
   }
  public static void main(String []args)
   {
	int []arr = {7, 7, 3, 6, 6,6};
	int arr_size = arr.length;
	HashMap<Integer,Integer> frequency = findRepeating(arr, arr_size);
	System.out.println("Below is the frequency Number"	+"of Duplicated numbers -");
	for (Map.Entry<Integer,Integer> entry : frequency.entrySet())
		if (entry.getValue() > 1)
			System.out.println(entry.getKey()+ "\tOriginal Number: --> Duplicate Number is:  "+entry.getValue());
   }
}*/