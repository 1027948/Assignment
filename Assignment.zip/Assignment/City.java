import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class City
{
   String CityName;
   float cpopulation;
   double carea;

   City(String cityname,float citypopulation, double area)
   {
       super();
       this.CityName=cityname;
       this.cpopulation=citypopulation;
       this.carea=area;
   }
   public static void main(String args[])
   {
       ArrayList<City> city =new ArrayList<City>();

       System.out.print("Highest Population in the City Name:: \n");

       city.add(new City("Ahmednagar",18960,1045.89));
       city.add(new City("Hydrabad",332960,1205.89));
       city.add(new City("Nagpur",459060,1405.89));
       city.add(new City("Pune",546660,2045.89));
       city.add(new City("Mumbai",9677000,64500.89));

       City Item = city.stream().max((obj1,obj2)->obj1.cpopulation>obj2.cpopulation?1:-1).get();
       System.out.print(Item.CityName);

       System.out.print("\nPopulated city are Here: \n");

       List<Float> namesets= city.stream().map(e->e.cpopulation).collect(Collectors.toList());
       System.out.print(namesets);
    
       System.out.print("\nHighest Populated City Area are Here: \n");
       City minArea = city.stream().min((obj1,obj2)->obj1.carea>obj2.carea?1:-1).get();
       System.out.print(minArea.carea);
   }
}