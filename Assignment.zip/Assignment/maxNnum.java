/*Que:WAP to print maxium of nth nos from array using lambda expression.*/
import java.util.Arrays;
interface NthBigNo 
{
	public int Nth(int[] tmp, int x);
}
public class maxNnum 
{	
	public static void main(String[] args) 
	{
		int[] numArray = { 6,4,2,98,7};
		System.out.println("\nThe Max number from Array :");
		System.out.print("[");

		dispArray(numArray);

		    NthBigNo Nb = ((numArr, pos) -> {
			Arrays.sort(numArr);
			return numArr[numArr.length - pos];
		});
		System.out.println("print maxium of nth nos from array using lambda expression :: \n" + Nb.Nth(numArray, 1));
	}

	private static void dispArray(int[] numArray) {
		for (int i = 0; i < numArray.length; i++) {
			System.out.print(numArray[i] + " ");
		}
		System.out.println("]\n");
	}
}