//2.WAP to find a character using lambda expression .

interface Char
{
	public void  ch();
}
public class Q2FindChar
{
public static void main(String args[])
{  //lambda expression .
	Char c1=() ->{
		String str=" Hello World in the Yash Technology"; //find the charactesr in this sentence.
		char a[]=str.toCharArray();
		if(str.contains("l"))  // find character "l" .  
		{
			System.out.println("True");//then character is present in string so i can return True.
		}
		else
		{
			System.out.println("False");//character is not finding this string it's return False.
		}
	};
	c1.ch();
}
}





/*
class Q2FindChar {
	// To check String for only Characters
	public static boolean isStringOnlyAlphabet(String str){
		return ((str != null) && (!str.equals("")) && (str.chars().allMatch(Character::isLetter)));
	}
	public static void main(String[] args){// calling method over diffrent strings

		System.out.println("This is original Character_String: case-1:");// print msg in output console
		String str1 = "AppleforApple";  //original character String
		System.out.println("Input: " + str1);
		System.out.println("Output: "+ isStringOnlyAlphabet(str1));// Calling over above string: AppleforApple

		System.out.println("\nCheckout the Character String: case-2:");//Checking for String with numeric characters
		String str2 = "Apple4Apple";
		System.out.println("Input: " + str2);
		System.out.println("Output: "+ isStringOnlyAlphabet(str2));// Calling over above string: Apple4Apple
		
		System.out.println("\nCheckout the Character String: case-3:");//null String is check
		String str3 = null;
		System.out.println("Input: " + str3);
		System.out.println("Output: "+ isStringOnlyAlphabet(str3));// Calling over above string: null
	}
}
*/










/*import java.util.Scanner;
interface LambdaExp
{
   void show();
}
public class Character{
	public static void main(String s[]){
		LambdaExp obj = ()->
		{
			String s1="IshwariDeshmukh";
			char ch[]=s1.toCharArray();
			int index;
			Scanner sc= new Scanner(System.in);
			System.out.println("\nIndex Number : ");
			index=sc.nextInt();
			System.out.println("find a character using lambda expression:: "+ch[index]);
			sc.close();
		};
		obj.show();
	}
}
*/