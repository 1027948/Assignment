import java.lang.reflect.Array;
import java.util.Scanner;
interface A
{

}
public abstract class MaxNumber implements A {
    public static void main(String s[])
    {
      Scanner sc= new Scanner(System.in);
      int n=5;
      int[] aa=new int [n];
      System.out.println("Enter Number:");
      for(int i=0;i<n-1;i++)
      {
          aa[i]=sc.nextInt();
      }
      Array.sort(aa);
      A lambda= () ->System.out.println("The Maximum Number is >>"+aa[n-1]);
      lambda.MaxNumber();
      sc.close();
    }
}
