package com.yash;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UserList {
 public static void main(String s[])
 {
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationcontext.xml");
		UserDAO udao = (UserDAO) objAC.getBean("userdao");
		
		/*
		 * User u = udao.getUserByMobile("9978783423");
		 * System.out.println(u.getId()+"\t"+u.getFirstname()+" \t "+u.getLastname()
		 * +" \t "+u.getAdd1()+" \t "+u.getAdd2()+" \t "+u.getDob()
		 * +" \t "+u.getEmail()+" \t "+u.getPassword()+" \t "+u.getCity());
		 */
		//System.out.println(e.getEname() +"---"+  e.getEadd());
		
		  //List<User> elist=udao.getUserByMobile("9978783423");
			
			
			/*
			 * User u = udao.getUserByMobiles("9978783123");
			 * System.out.println(u.getId()+"\t"+u.getFirstname()+" \t "+u.getLastname()
			 * +" \t "+u.getAdd1()+" \t "+u.getAdd2()+" \t "+u.getDob()
			 * +" \t "+u.getEmail()+" \t "+u.getPassword()+" \t "+u.getCity()+" \t "+u.
			 * getMobileNo());
			 */ 
		 /* System.out.println("Userid\t FirstName \t LastName \t Add1 \t Add2 \t DOB \t Email \t Password \t City \t Mobile"); 
		  for(User u: elist) 
		  {
		  System.out.println(u.getId()+"\t"+u.getFirstname()+" \t "+u.getLastname()
		  +" \t "+u.getAdd1()+" \t "+u.getAdd2()+" \t "+u.getDob()
		  +" \t "+u.getEmail()+" \t "+u.getPassword()+" \t "+u.getCity()+" \t "+u.getMobileNo()); 
		  }*/
			  
		User objU = new User();

		//objU.setMobileNo("9978783123");
		objU.setId(3);
		udao.getUserDelete(objU);
		
 }
}
