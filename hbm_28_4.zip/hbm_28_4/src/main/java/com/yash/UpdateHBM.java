package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UpdateHBM {
  public static void main(String s[])
	{
			ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationcontext.xml");
			UserDAO udao = (UserDAO) objAC.getBean("userdao");
			User objU = new User();
			/*objE.setEname("namdev falke");
			objE.setEadd("vijay nagar mumbai");
			objE.setSalary(48000);
			objE.setId(2);
			edao.updateEmp(objE);*/
			objU.setFirstname("Aryan");
			objU.setLastname("Sharma");
			objU.setAdd1("Vaibhav Apt");
			objU.setAdd2("near Sai temple");
			objU.setDob("2019-06-01");
			objU.setEmail("aryan.sharma@yash.com");
			objU.setPassword("test@6743");
			objU.setCity("Vashi");
			objU.setMobileNo("9978783523");
			objU.setId(2);
			udao.updateUser(objU);
	}
}
