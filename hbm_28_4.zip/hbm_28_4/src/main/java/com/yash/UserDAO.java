package com.yash;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;

public class UserDAO {
	HibernateTransactionManager hbmtemplate;

	public void setHbmtemplate(HibernateTransactionManager hbmtemplate) {
		this.hbmtemplate = hbmtemplate;
	}
	public void saveUser(User e)
	{	
		  SessionFactory sf= hbmtemplate.getSessionFactory();
		  Session objSession = sf.openSession();
		  Transaction t = objSession.beginTransaction();
		  
		  objSession.save(e);
		  
		  t.commit();
		  System.out.println("Record saved");
		  objSession.close();		  
	}
	public void updateUser(User e)
	{
		  SessionFactory sf= hbmtemplate.getSessionFactory();
		  Session objSession = sf.openSession();
		  Transaction t = objSession.beginTransaction();
		  objSession.update(e.getMobileNo(), e);
		  
		  t.commit();
		 System.out.println("Data updated");
	}
	public User getUserByMobiles(String mobileNo)
	{
		
		  SessionFactory sf= hbmtemplate.getSessionFactory(); 
		  Session objSession =sf.openSession();
		 
		Transaction t = objSession.beginTransaction();
		Criteria ctr = objSession.createCriteria(User.class);
		ctr.add(Restrictions.eq("mobileNo", mobileNo));
		User objU = (User) ctr.uniqueResult();
		return objU;		
	}
	public List<User> getUserByMobile(String mobile)
	{
		SessionFactory sf= hbmtemplate.getSessionFactory();
		Session objSession = sf.openSession();
		//Transaction t = objSession.beginTransaction();
		List<User> userlist = new ArrayList<User>();
		Criteria ctr = objSession.createCriteria(User.class,mobile);
		userlist = ctr.list();
		return userlist;		
	}
	public void getUserDelete(User u){  

		SessionFactory sf= hbmtemplate.getSessionFactory();
		Session objSession = sf.openSession();
		Transaction t = objSession.beginTransaction();
		
		System.out.println("getId "+u.getId());
		objSession.delete(u);
		t.commit();
		System.out.println("Data Deleted");
	}  
}
