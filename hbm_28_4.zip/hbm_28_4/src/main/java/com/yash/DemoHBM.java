package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DemoHBM {
	public static void main(String s[])
	{
			ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationcontext.xml");
			UserDAO edao = (UserDAO) objAC.getBean("userdao");
			User objU = new User();
			objU.setFirstname("Viraj ");
			objU.setLastname("Sathe");
			objU.setAdd1("Vaibhav Apt");
			objU.setAdd2("mirja Nagar");
			objU.setDob("2017-01-19");
			objU.setEmail("viraj.sathe@yash.com");
			objU.setPassword("test@4002");
			objU.setCity("Malad");
			objU.setMobileNo("9978783323");
			
			edao.saveUser(objU);
	}
}
