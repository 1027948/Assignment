class student {
    studId: number;
    studName: string;
    phy: number;
    chem: number;
    bio: number;
    math: number;
    constructor(Id: number, name: string,phy:number, chem:number, bio: number, math:number) 
	{
        this.studId = Id;
		this.studName = name;
        this.phy = phy;
        this.chem = chem;
        this.bio = bio;
        this.math = math;
    }
    display = () => console.log(this.studId +'\n' + this.studName +'\n' + this.phy +'\n' +this.chem +'\n' +this.bio +'\n' + this.math)
}
let stud = new student(1, 'Ishwari Marks List: ', 76, 88, 85, 72);
stud.display();

/** output console:

D:\Typescript Assignment1>node ass1.js
1 Ishwari Marks List:  76 88 85 72

D:\Typescript Assignment1>tsc ass1.ts

D:\Typescript Assignment1>node ass1.js
1
Ishwari Marks List:
76
88
85
72
**/