// Base class

class shape {
A(): void {
	console.log("Rectangal=l*h");
	console.log("Square=sq*sq");
}
}

class Rectangal extends shape {
l:number;
h:number;
B(): void {
	console.log("Rectangal Ans = "+5*5);
}
}

class Square extends Rectangal {
sq:number;
C(): void {
	console.log("Square Ans = "+5*5);
}
}

// Object creation
let obj = new Square();
obj.A();
obj.B();
obj.C();

/**output:

D:\Typescript Assignment1>node shape.js
Rectangal=l*h
Square=sq*sq
Rectangal Ans=25
Square Ans = 25

  **/
