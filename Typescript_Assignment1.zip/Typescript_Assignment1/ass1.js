var student = /** @class */ (function () {
    function student(Id, name, phy, chem, bio, math) {
        var _this = this;
        this.display = function () { return console.log(_this.studId + '\n' + _this.studName + '\n' + _this.phy + '\n' + _this.chem + '\n' + _this.bio + '\n' + _this.math); };
        this.studId = Id;
        this.studName = name;
        this.phy = phy;
        this.chem = chem;
        this.bio = bio;
        this.math = math;
    }
    return student;
}());
var stud = new student(1, 'Ishwari Marks List: ', 76, 88, 85, 72);
stud.display();
/** output console:

D:\Typescript Assignment1>node ass1.js
1 Ishwari Marks List:  76 88 85 72

D:\Typescript Assignment1>tsc ass1.ts

D:\Typescript Assignment1>node ass1.js
1
Ishwari Marks List:
76
88
85
72
**/ 
