package com.yash.dao;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;

import com.yash.controller.Store;

  
public class StoreDao {  
	@Autowired	
	JdbcTemplate objJdbc;
	public void setObjJdbc(JdbcTemplate objJdbc) {
	}
public int save(Store objs){  
	String sql="insert into admin (name,pass,email,mobileno) values(?,?,?,?)";
	 return objJdbc.update(sql, objs.getName(),objs.getPass(),objs.getEmailid(),Long.parseLong(objs.getMobileno()) );

}  

public Store validate(Store objs){  
    String sql="select * from admin where name='"+objs.getName()+"' pass='"+objs.getPass()+"'";
    List<Store> stores=objJdbc.query(sql, new BeanPropertyRowMapper<Store>(Store.class));
    return stores.size() > 0 ? stores.get(0) : null;  
}  

public int saveItem(Store objs){  
	String sql="insert into item (itemName,itemPrice,itemManuDate,itemExpiryDate,category) values(?,?,?,?,?)";
	 return objJdbc.update(sql, objs.getItemName(),objs.getItemPrice(),objs.getItemManuDate(),objs.getItemExpiryDate(),objs.getCategory());

}  
public int saveCustomer(Store objs){  
	String sql="insert into customer (custname,emailid,password,address,mobileno) values(?,?,?,?,?)";
	 return objJdbc.update(sql, objs.getCustname(),objs.getEmailid(),objs.getPassCust(),objs.getAddress(),objs.getMobileno());

}  
public int saveCategory(Store objs){  
	String sql="insert into category (categoryid,category) values(?,?)";
	 return objJdbc.update(sql, objs.getCategoryid(),objs.getCategory());

}  
 
public Store getItemById(int id){  
    String sql="select * from item where itemId=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Store>(Store.class));  
}  
public Store getCustById(int id){  
    String sql="select * from customer where custid=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Store>(Store.class));  
}  
public Store getCategoryById(int id){  
    String sql="select * from category where categoryid=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Store>(Store.class));  
}  
public List<Store> getAllItem(){  
    return objJdbc.query("select * from item",new RowMapper<Store>(){  
        public Store mapRow(ResultSet rs, int row) throws SQLException {  
            Store objs=new Store(); 
            objs.setItemId(rs.getInt("itemId"));            
            objs.setItemName(rs.getString("itemName"));
			  objs.setItemPrice(rs.getString("itemPrice"));
			  objs.setItemManuDate(rs.getString("itemManuDate"));
			  objs.setItemExpiryDate(rs.getString("itemExpiryDate"));
			  objs.setCategory(rs.getString("category"));
			  return objs;
        }  
    });  
}  
public List<Store> getAllCustomer(){  
    return objJdbc.query("select * from customer",new RowMapper<Store>(){  
        public Store mapRow(ResultSet rs, int row) throws SQLException {  
            Store objs=new Store(); 
            objs.setCustid(rs.getInt("custid"));            
            objs.setCustname(rs.getString("custname"));
			  objs.setEmailid(rs.getString("emailid"));
			  objs.setPassCust(rs.getString("password"));
			  objs.setAddress(rs.getString("address"));
			  objs.setMobileno(rs.getString("mobileno"));

			  return objs;
        }  
    });  
} 
public List<Store> getAllCategory(){  
    return objJdbc.query("select * from category",new RowMapper<Store>(){  
        public Store mapRow(ResultSet rs, int row) throws SQLException {  
            Store objs=new Store(); 
            objs.setCategoryid(rs.getInt("categoryid"));            
            objs.setCategory(rs.getString("category"));
			  return objs;
        }  
    });  
} 

public int updateitem(Store p){  
    String sql="update item set itemName='"+p.getItemName()+"', itemPrice='"+p.getItemPrice()+"',itemManuDate='"+p.getItemManuDate()+"',itemExpiryDate='"+p.getItemExpiryDate()+"' where itemid="+p.getItemId()+"";    
    return objJdbc.update(sql);  
}  
public int updatecust(Store p){  
	//System.out.println("ID "+p.getCustid());
    String sql="update customer set custname='"+p.getCustname()+"', emailid='"+p.getEmailid()+"',password='"+p.getPassCust()+"',address='"+p.getAddress()+"',mobileno="+Long.parseLong(p.getMobileno())+" where custid="+p.getCustid();    
    return objJdbc.update(sql);  
}
public int updatecategory(Store p){  
    String sql="update category set category='"+p.getCategory()+"' where categoryid="+p.getCategoryid()+"";    
    return objJdbc.update(sql);  
}  

}  