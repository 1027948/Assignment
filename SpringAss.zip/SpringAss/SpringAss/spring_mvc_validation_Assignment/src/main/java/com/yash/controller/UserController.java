package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.catalina.realm.X509UsernameRetriever;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.yash.dao.*;
@Controller  
public class UserController {  
    @Autowired  
    UserDao userdao;//will inject dao from xml file  
      
    @RequestMapping(value="/")
	public String first()
	{
		return "index";
	}
	@GetMapping("/login")
	public String userLogin()
	{		
		return "userlogin";
	}
	@GetMapping("/signup")
	public String userReg(Model m)
	{
		User objuser = new User();
		m.addAttribute("objuser", objuser);
		return "signup";
	}
	@PostMapping("/SignUpSubmit")
	public String UserRegSubmit(@Valid @ModelAttribute("objuser") User objuser, BindingResult objBR)
	{
		if(objBR.hasErrors())
		  return "signup";
		else
		{
			if(userdao.save(objuser)==1)
				return "signup_success";
			else
				return "index";
			
		}
	}  
 
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("user") User user){  
    	userdao.save(user);  
        return "viewuser";//will redirect to viewuser request mapping  
    }  
   
    @RequestMapping("/viewuser")  
    public String viewuser(Model m){  
        List<User> list=userdao.getAllUser();  
        m.addAttribute("list",list);
        return "viewuser";  
    }  

    @RequestMapping(value="/edituser/{uid}")  
    public String edit(@PathVariable int uid, Model m){  
        User user=userdao.getUserById(uid);  
        m.addAttribute("objuser",user);
        return "usereditform";  
    }  
    /* It updates model object. */  
    @PostMapping(value="/editsave")  
    public String editsave(@ModelAttribute("objuser") User user,BindingResult br,Model m){ 
    	
    	System.out.println("Name "+user.getName()+" Mobile "+user.getMobileno());
    	userdao.update(user);  
    	List<User> list=userdao.getAllUser(); 
    	m.addAttribute("list",list);
        return "viewuser";  
    }  

    @RequestMapping(value="/deleteuser/{uid}",method = RequestMethod.GET)  
    public String delete(@PathVariable int uid,Model m){ 
    	System.out.println("ID "+uid);
    	userdao.delete(uid);  
    	List<User> list=userdao.getAllUser(); 
    	m.addAttribute("list",list);
        return "viewuser";  
    }   
}  