package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.catalina.realm.X509UsernameRetriever;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.yash.bean.User;
import com.yash.dao.*;
@Controller  
public class UserController {  
    @Autowired  
    UserDao userdao;//will inject dao from xml file  
      
    @RequestMapping(value="/")
	public String first()
	{
		return "index";
	}
	@GetMapping("/signup")
	public String userReg(Model m)
	{
		User objuser = new User();
		m.addAttribute("objuser", objuser);
		return "signup";
	}
	@PostMapping("/SignUpSubmit")
	public String UserRegSubmit(@Valid @ModelAttribute("objuser") User objuser, BindingResult objBR
			,HttpServletRequest req,Model m)
	{
		if(objBR.hasErrors())
		{
		  return "signup";
		
		}else
		{
			String email=req.getParameter("email");
			System.out.println("Email> "+email);
			objuser=userdao.validate(objuser);
			m.addAttribute("objuser", objuser);
			System.out.println("Email>> "+email);
			if(!email.equals(objuser.getEmail()))
			{
				if(userdao.save(objuser)==1)
				{
					return "signup_success";
				}else
				{
					return "index";
				}
			}
			else
			{
				return "index";
			}
		}
		//return null;
	}  
	@GetMapping("/login")
	public String userLogin(Model m)
	{	
		User objuser = new User();
		m.addAttribute("objuser", objuser);
		return "adminlogin";
	}
	//@PostMapping(value="/loginSuccess")
    /*@RequestMapping(value="/loginSuccess",method = RequestMethod.POST)  

	public String UserloginSubmit(@Valid @ModelAttribute("objUser") User objUser, BindingResult objBR,Model m)
	{
			System.out.println(" Name "+objUser.getName()+"Password "+objUser.getPass());
			if(objUser != null && objUser.getName()!=null && objUser.getPass()!=null)
			{
				if(objUser.getName().equals("TEJAS65") && objUser.getPass().equals("nhagf12345"))
				{
					m.addAttribute(objUser);
					return "loginSuccesss";
				}
				return "adminNotFound";

			}
			else
				return "adminNotFound";
			
	} */
	/*
	 * @RequestMapping("/view") public String view(Model m){ List<User>
	 * list=userdao.getAllItem(); m.addAttribute("list",list); return "view"; }
	 * 
	 * @RequestMapping("/viewCustomerDeatil") public String viewCustomerDetail(Model
	 * m){ List<User> list=userdao.getAllCustomer(); m.addAttribute("list",list);
	 * return "viewCustomerDeatil"; }
	 * 
	 * @RequestMapping("/viewCategory") public String viewCategory(Model m){
	 * List<User> list=userdao.getAllCategory(); m.addAttribute("list",list); return
	 * "viewCategory"; }
	 * 
	 * @GetMapping("/AddItem") public String AddItem(Model m) { User objuser = new
	 * User(); m.addAttribute("objUser", objuser); return "AddItem"; }
	 * //@PostMapping("/addDeatil")
	 * 
	 * @RequestMapping(value="/addItemDeatil",method = RequestMethod.POST) public
	 * String addDetails(@Valid @ModelAttribute("objUser") User objUser,
	 * BindingResult objBR,Model m) { userdao.saveItem(objUser); List<User>
	 * list=userdao.getAllItem(); m.addAttribute("list",list); return "view";
	 * 
	 * }
	 * 
	 * @GetMapping("/AddCustomer") public String AddCustomer(Model m) { User objuser
	 * = new User(); m.addAttribute("objUser", objuser); return "AddCustomer"; }
	 * 
	 * @RequestMapping(value="/addCustomerDeatil",method = RequestMethod.POST)
	 * public String addCustomerDetails(@Valid @ModelAttribute("objUser") User
	 * objUser, BindingResult objBR,Model m) { userdao.saveCustomer(objUser);
	 * List<User> list=userdao.getAllCustomer(); m.addAttribute("list",list); return
	 * "viewCustomerDeatil";
	 * 
	 * }
	 * 
	 * @GetMapping("/AddCategory") public String AddCategory(Model m) { User objuser
	 * = new User(); m.addAttribute("objUser", objuser); return "AddCategory"; }
	 * 
	 * @RequestMapping(value="/addCategoryDeatil",method = RequestMethod.POST)
	 * public String addCategoryDeatil(@Valid @ModelAttribute("objUser") User
	 * objUser, BindingResult objBR,Model m) { userdao.saveCategory(objUser);
	 * List<User> list=userdao.getAllCategory(); m.addAttribute("list",list); return
	 * "viewCategory";
	 * 
	 * }
	 * 
	 * @RequestMapping(value="/edititem/{itemId}") public String
	 * editItem(@PathVariable int itemId, Model m){ User
	 * objUser=userdao.getItemById(itemId); m.addAttribute("objUser",objUser);
	 * return "itemeditform"; }
	 * 
	 * @PostMapping(value="/editi") public String
	 * editsave(@ModelAttribute("objUser") User objUser,BindingResult br,Model m){
	 * 
	 * userdao.updateitem(objUser); List<User> list=userdao.getAllItem();
	 * m.addAttribute("list",list); return "view"; }
	 * 
	 * @RequestMapping(value="/editCust/{custid}") public String
	 * editCust(@PathVariable int custid, Model m){ User
	 * objUser=userdao.getCustById(custid); m.addAttribute("objUser",objUser);
	 * return "custeditform"; }
	 * 
	 * @PostMapping(value="/editcust") public String
	 * editcust(@ModelAttribute("objUser") User objUser,BindingResult br,Model m){
	 * 
	 * userdao.updatecust(objUser); List<User> list=userdao.getAllCustomer();
	 * m.addAttribute("list",list); return "viewCustomerDeatil"; }
	 * 
	 * @RequestMapping(value="/editCategory/{categoryid}") public String
	 * editCategory(@PathVariable int categoryid, Model m){ User
	 * objUser=userdao.getCategoryById(categoryid);
	 * m.addAttribute("objUser",objUser); return "categoryeditform"; }
	 * 
	 * @PostMapping(value="/editcat") public String
	 * editcat(@ModelAttribute("objUser") User objUser,BindingResult br,Model m){
	 * 
	 * userdao.updatecategory(objUser); List<User> list=userdao.getAllCategory();
	 * m.addAttribute("list",list); return "viewCategory"; }
	 */
}  