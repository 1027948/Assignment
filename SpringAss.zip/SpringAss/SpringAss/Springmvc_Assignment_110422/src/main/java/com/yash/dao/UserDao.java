package com.yash.dao;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;

import com.yash.bean.User;

  
public class UserDao {  
	@Autowired	
	JdbcTemplate objJdbc;
	public void setObjJdbc(JdbcTemplate objJdbc) {
	}
public int save(User objs){  
	
	System.out.println(this.validate(objs));
	return 0;
	/*
	 * String sql="insert into admin (name,pass,email,mobileno) values(?,?,?,?)";
	 * return objJdbc.update(sql,
	 * objs.getName(),objs.getPass(),objs.getEmailid(),Long.parseLong(objs.
	 * getMobileno()) );
	 */
}  

public User validate(User objs){  
    String sql="select * from admin where email='"+objs.getEmail()+"'";
   // List<User> Users=objJdbc.query(sql, new BeanPropertyRowMapper<User>(User.class));
    return (User)objJdbc.query(sql, new BeanPropertyRowMapper<User>(User.class));  
}  

public int saveItem(User objs){  
	String sql="insert into item (itemName,itemPrice,itemManuDate,itemExpiryDate,category) values(?,?,?,?,?)";
	 return objJdbc.update(sql, objs.getItemName(),objs.getItemPrice(),objs.getItemManuDate(),objs.getItemExpiryDate(),objs.getCategory());

}  
public int saveCustomer(User objs){  
	String sql="insert into customer (custname,emailid,password,address,mobileno) values(?,?,?,?,?)";
	 return objJdbc.update(sql, objs.getCustname(),objs.getEmail(),objs.getPassCust(),objs.getAddress(),objs.getMobileno());

}  
public int saveCategory(User objs){  
	String sql="insert into category (categoryid,category) values(?,?)";
	 return objJdbc.update(sql, objs.getCategoryid(),objs.getCategory());

}  
 
public User getItemById(int id){  
    String sql="select * from item where itemId=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<User>(User.class));  
}  
public User getCustById(int id){  
    String sql="select * from customer where custid=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<User>(User.class));  
}  
public User getCategoryById(int id){  
    String sql="select * from category where categoryid=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<User>(User.class));  
}  
public List<User> getAllItem(){  
    return objJdbc.query("select * from item",new RowMapper<User>(){  
        public User mapRow(ResultSet rs, int row) throws SQLException {  
            User objs=new User(); 
            objs.setItemId(rs.getInt("itemId"));            
            objs.setItemName(rs.getString("itemName"));
			  objs.setItemPrice(rs.getString("itemPrice"));
			  objs.setItemManuDate(rs.getString("itemManuDate"));
			  objs.setItemExpiryDate(rs.getString("itemExpiryDate"));
			  objs.setCategory(rs.getString("category"));
			  return objs;
        }  
    });  
}  
public List<User> getAllCustomer(){  
    return objJdbc.query("select * from customer",new RowMapper<User>(){  
        public User mapRow(ResultSet rs, int row) throws SQLException {  
            User objs=new User(); 
            objs.setCustid(rs.getInt("custid"));            
            objs.setCustname(rs.getString("custname"));
			  objs.setEmail(rs.getString("emailid"));
			  objs.setPassCust(rs.getString("password"));
			  objs.setAddress(rs.getString("address"));
			  objs.setMobileno(rs.getString("mobileno"));

			  return objs;
        }  
    });  
} 
public List<User> getAllCategory(){  
    return objJdbc.query("select * from category",new RowMapper<User>(){  
        public User mapRow(ResultSet rs, int row) throws SQLException {  
            User objs=new User(); 
            objs.setCategoryid(rs.getInt("categoryid"));            
            objs.setCategory(rs.getString("category"));
			  return objs;
        }  
    });  
} 

public int updateitem(User p){  
    String sql="update item set itemName='"+p.getItemName()+"', itemPrice='"+p.getItemPrice()+"',itemManuDate='"+p.getItemManuDate()+"',itemExpiryDate='"+p.getItemExpiryDate()+"' where itemid="+p.getItemId()+"";    
    return objJdbc.update(sql);  
}  
public int updatecust(User p){  
	//System.out.println("ID "+p.getCustid());
    String sql="update customer set custname='"+p.getCustname()+"', emailid='"+p.getEmail()+"',password='"+p.getPassCust()+"',address='"+p.getAddress()+"',mobileno="+Long.parseLong(p.getMobileno())+" where custid="+p.getCustid();    
    return objJdbc.update(sql);  
}
public int updatecategory(User p){  
    String sql="update category set category='"+p.getCategory()+"' where categoryid="+p.getCategoryid()+"";    
    return objJdbc.update(sql);  
}  

}  